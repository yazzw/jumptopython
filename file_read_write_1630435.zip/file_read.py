# Read the file
f = open("mobis_1630435.txt",'r')
data = f.read()
print(data)
f.close()